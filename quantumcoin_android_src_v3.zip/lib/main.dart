import 'package:flutter/material.dart'; import 'package:provider/provider.dart';
import 'theme/theme.dart'; import 'screens/home/home_screen.dart'; import 'services/api_service.dart';
void main(){ runApp(const QuantumApp()); }
class QuantumApp extends StatelessWidget{ const QuantumApp({super.key});
  @override Widget build(BuildContext context){ return MultiProvider(providers:[ ChangeNotifierProvider(create: (_)=>ApiService()), ],
    child: MaterialApp(title:'QuantumCoin Wallet', theme: QuantumTheme.dark, debugShowCheckedModeBanner:false, home: const HomeScreen())); } }
