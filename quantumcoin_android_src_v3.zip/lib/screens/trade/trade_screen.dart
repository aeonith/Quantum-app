import 'package:flutter/material.dart'; import 'package:provider/provider.dart'; import '../../services/api_service.dart';
class TradeScreen extends StatefulWidget{ const TradeScreen({super.key}); @override State<TradeScreen> createState()=>_TradeScreenState(); }
class _TradeScreenState extends State<TradeScreen>{ final _amountCtrl=TextEditingController(text:'1'); String _status='';
  @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: const Text('Trade QTC')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
    TextField(controller:_amountCtrl, decoration: const InputDecoration(labelText:'Amount to buy'), keyboardType: TextInputType.number),
    const SizedBox(height:12),
    ElevatedButton(onPressed: () async{ setState(()=>_status='Placing order…'); try{ final api=context.read<ApiService>(); final amt=int.tryParse(_amountCtrl.text.trim())??0;
      final res=await api.buyQtc(amt); setState(()=>_status='Success: ${res.toString()}'); }catch(e){ setState(()=>_status='Failed: $e'); } }, child: const Text('Buy QTC')),
    const SizedBox(height:12), Text(_status), ],),),); } }
