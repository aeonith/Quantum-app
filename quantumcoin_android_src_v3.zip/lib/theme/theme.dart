import 'package:flutter/material.dart';
class QuantumTheme {
  static ThemeData get dark => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF0B0E14),
    colorScheme: const ColorScheme.dark(primary: Color(0xFF00E5FF), secondary: Color(0xFF8A2BE2)),
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0B0E14), elevation: 0, centerTitle: true,
      titleTextStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      foregroundColor: Colors.black, backgroundColor: const Color(0xFF00E5FF), elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
    cardTheme: CardTheme(color: const Color(0xFF101521), elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
  );
}
