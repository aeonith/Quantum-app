import 'dart:convert'; import 'package:flutter/foundation.dart'; import 'package:http/http.dart' as http; import '../constants.dart';
class ApiService with ChangeNotifier{
  String? _authToken;
  Map<String,String> get _headers => {'Content-Type':'application/json', if(_authToken!=null) 'Authorization':'Bearer $_authToken'};
  Uri _u(String path,[Map<String,dynamic>? q]){ final base=AppConstants.baseUrl.replaceAll(RegExp(r'/+$'),''); return Uri.parse('$base$path').replace(queryParameters:q); }
  Future<bool> health() async{ try{ final r=await http.get(_u('/health')); return r.statusCode==200; }catch(_){ return false; } }
  Future<int> getQtcLiquidity() async{ try{ final r=await http.get(_u('/liquidity/qtc'), headers:_headers); if(r.statusCode==200){ final d=jsonDecode(r.body); final a=d['available']; return (a is int)?a:(a as num).toInt(); } }catch(_){}
    return 0; }
  Future<Map<String,dynamic>> buyQtc(int amount) async{ final body=jsonEncode({'amount':amount}); final r=await http.post(_u('/trade/buy'), headers:_headers, body:body);
    if(r.statusCode>=200 && r.statusCode<300){ return jsonDecode(r.body) as Map<String,dynamic>; } throw Exception('Buy failed: ${r.statusCode} ${r.body}'); }
}
