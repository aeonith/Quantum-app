# QuantumCoin Wallet — Android-ready Flutter source (v3)

## Build locally (USB-friendly)
```powershell
flutter create .
flutter pub get
flutter build appbundle --release --dart-define=API_BASE_URL=https://your-backend.example.com
```
AAB: `build/app/outputs/bundle/release/app-release.aab`

## Build in GitHub Actions (no local build)
Push this folder to a repo (or upload the zip). The included workflow `.github/workflows/android-aab.yml` builds the AAB in the cloud.
First run generates an `upload-keystore.jks` artifact; save it and add as base64 repo secret `KEYSTORE_BASE64` for future runs.
