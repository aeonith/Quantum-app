import 'package:flutter/material.dart'; import 'package:provider/provider.dart';
import '../../services/api_service.dart'; import '../../widgets/animated_background.dart'; import '../trade/trade_screen.dart';
class HomeScreen extends StatefulWidget{ const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{ int _available=-1; bool _healthy=false;
  @override void initState(){ super.initState(); Future.microtask(() async{ final api=context.read<ApiService>(); final ok=await api.health(); final qty=await api.getQtcLiquidity();
    if(!mounted) return; setState((){ _healthy=ok; _available=qty; }); }); }
  @override Widget build(BuildContext context){ final unavailable=_available==0 || !_healthy; return NeonStormBackground(child: Scaffold(
    backgroundColor: Colors.transparent, appBar: AppBar(title: const Text('QuantumCoin')), body: Padding(padding: const EdgeInsets.all(16), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children:[ if(_available==-1) const LinearProgressIndicator(minHeight:3),
        if(!_healthy) const _Banner(text:'Backend unreachable — check API_BASE_URL or server health.'),
        if(_healthy && _available==0) const _Banner(text:'Trading unavailable — no QTC liquidity yet.'), const SizedBox(height:16),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
          const Text('QTC Balance', style: TextStyle(fontSize:16,fontWeight:FontWeight.w700)), const SizedBox(height:8),
          const Text('0.000000 QTC', style: TextStyle(fontSize:28,fontWeight:FontWeight.w800)), const SizedBox(height:4),
          Text(_available>=0 ? 'Available to buy: $_available' : 'Checking liquidity…'),
        ]))), const Spacer(),
        ElevatedButton(onPressed: unavailable? null : ()=> Navigator.push(context, MaterialPageRoute(builder:(_)=>const TradeScreen())),
          child: Text(unavailable? 'Trading unavailable' : 'Trade QTC')), ],)),)); }}
class _Banner extends StatelessWidget{ final String text; const _Banner({required this.text}); @override Widget build(BuildContext context){
  return Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.orange.withOpacity(0.12),
    borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.orange.withOpacity(0.5))), child: Row(children:[
      const Icon(Icons.info_outline, color: Colors.orange), const SizedBox(width:8), Expanded(child: Text(text)), ],),); } }
