import 'dart:async'; import 'dart:math'; import 'package:flutter/material.dart';
class NeonStormBackground extends StatefulWidget { final Widget child; final bool lightningEnabled;
  const NeonStormBackground({super.key, required this.child, this.lightningEnabled = true});
  @override State<NeonStormBackground> createState() => _NeonStormBackgroundState(); }
class _NeonStormBackgroundState extends State<NeonStormBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _rain; Timer? _flashTimer; double _flashOpacity = 0;
  @override void initState(){ super.initState(); _rain = AnimationController(vsync:this,duration:const Duration(seconds:1))..repeat(); _scheduleLightning(); }
  void _scheduleLightning(){ if(!widget.lightningEnabled) return; _flashTimer?.cancel(); final rnd=Random(); final next=Duration(seconds:5+rnd.nextInt(11));
    _flashTimer = Timer(next, (){ setState(()=>_flashOpacity=0.0); Timer.periodic(const Duration(milliseconds:60),(t){ setState((){ _flashOpacity+=0.4;
      if(_flashOpacity>=1.2){ _flashOpacity=0; t.cancel(); _scheduleLightning(); } }); }); }); }
  @override void dispose(){ _flashTimer?.cancel(); _rain.dispose(); super.dispose(); }
  @override Widget build(BuildContext context){ return Stack(fit:StackFit.expand, children:[
    Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter,end: Alignment.bottomCenter,
      colors:[Color(0xFF0B0E14), Color(0xFF0A0C12), Color(0xFF06080D)]))), 
    AnimatedBuilder(animation:_rain, builder:(_,__)=>CustomPaint(painter:_RainPainter(progress:_rain.value))),
    IgnorePointer(child: AnimatedOpacity(opacity:_flashOpacity.clamp(0,1), duration: const Duration(milliseconds:120),
      child: Container(color: Colors.white.withOpacity(0.85)))),
    widget.child ]); } }
class _RainPainter extends CustomPainter{ final double progress; final int drops; _RainPainter({required this.progress,this.drops=220});
  @override void paint(Canvas c, Size s){ final rnd=Random(1337); final p=Paint()..color=const Color(0xFF00E5FF).withOpacity(0.25)..strokeWidth=1.1..strokeCap=StrokeCap.round;
    for(var i=0;i<drops;i++){ final x=rnd.nextDouble()*s.width; final len=8+rnd.nextDouble()*18; final speed=40+rnd.nextDouble()*90;
      final y=(progress*speed + rnd.nextDouble()*s.height)%s.height; c.drawLine(Offset(x,y), Offset(x+1.5,y+len), p); } }
  @override bool shouldRepaint(covariant _RainPainter o)=>o.progress!=progress; }
