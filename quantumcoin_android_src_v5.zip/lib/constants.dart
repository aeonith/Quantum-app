class AppConstants {
  static String baseUrl = const String.fromEnvironment('API_BASE_URL', defaultValue: 'https://api.example.com');
}
